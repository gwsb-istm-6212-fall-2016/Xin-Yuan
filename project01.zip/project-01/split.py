#!/usr/bin/env python

"""
A filter that split lines into one word per line.
"""

import fileinput


def process(line):
    a = ""
    whitespace = [" "]
    symbol = [",", ".", ":", "?", "*", "\n", "\t", "\r", None]
    
    for b in line:
        if b in whitespace:
           a = a + "\n"
        elif b in symbol:
           a = a
        else: 
           a = a + b
    
    print(a)
"""For each line of input, replace symbols and replace blankspace with a new line, split word per line."""   
    



for line in fileinput.input():
    process(line)
