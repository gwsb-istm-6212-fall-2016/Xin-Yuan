#!/usr/bin/env python

"""
A filter that remove top 10 words.
"""

import fileinput

from stop_words import get_stop_words

    
def process(line):
        
    stop_words = set(get_stopwords_words('and','the','to','of','her','it','in','you','she','for'))
    text = ' '.join([word for word in line.split() if word not in stop_words.words('and','the','to','of','her','it','in','you','she','for')])

    """For each line of input, remove listed words"""
    print(text)


for line in fileinput.input():
    process(line)
