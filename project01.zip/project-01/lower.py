#!/usr/bin/env python

"""
A filter that turn the uppercase into lowercase.
"""

import fileinput


def process(line):
    
    line = line[:-1].lower()
    """For each line of input, turn the uppercase into lowercase."""
    print(line)


for line in fileinput.input():
    process(line)
