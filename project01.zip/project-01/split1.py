#!/usr/bin/env python

"""
A filter that _________.
"""

import fileinput


def process(line):
    a = ""
    whitespace = [" "]
    symbol = [",", ".", ":", "?", "*", "\n", "\t", "\r", None]
    for b in line:
        if b not in whitespace:
             if b not in symbol:
                 a = a + b
        if b in symbol:
            a = a 
        if b in whitespace:
            a = a + "\n"
    """For each line of input, _____."""
    print(a)


for line in fileinput.input():
    process(line)
